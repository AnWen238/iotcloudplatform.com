print("hellow world") 
print("world")
print(3*6)